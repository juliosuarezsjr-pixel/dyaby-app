package com.dyaby.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.ViewGroup;
public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    WebView w = new WebView(this);
    w.setLayoutParams(new ViewGroup.LayoutParams(-1,-1));
    WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
    w.setWebViewClient(new WebViewClient());
    w.loadUrl("file:///android_asset/index.html");
    setContentView(w);
  }
}
